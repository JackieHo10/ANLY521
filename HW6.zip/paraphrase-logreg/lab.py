import argparse
import numpy as np


def main(sts_data):
    """Transform a semantic textual similarity dataset into a paraphrase identification.
    Data is formatted as in the STS benchmark"""

    max_nonparaphrase = 3.0
    min_paraphrase = 4.0

    # read the dataset
    texts = []
    labels = []

    # remove examples that are neither <= max_nonparaphrase nor >=min_paraphrase

    pi_texts = texts
    # 1221 for dev
    print(f"{len(pi_texts)} sentence pairs kept")

    # using indexing to get the right rows out of labels
    pi_y = labels

    num_nonparaphrase = (np.asarray(pi_y) == False).sum()
    num_paraphrase = (np.asarray(pi_y) == True).sum()
    # 957 for dev
    print(f"{num_nonparaphrase} non-paraphrase")
    # 264 for dev
    print(f"{num_paraphrase} paraphrase")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--sts_data", type=str, default="../sts_strings/stsbenchmark/sts-dev.csv",
                        help="tab separated sts data in benchmark format")
    args = parser.parse_args()

    main(args.sts_data)
