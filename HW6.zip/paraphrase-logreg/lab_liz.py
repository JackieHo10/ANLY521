import argparse
import numpy as np

def main(sts_data):
    """Transform a semantic textual similarity dataset into a paraphrase identification.
    Data is formatted as in the STS benchmark"""

    max_nonparaphrase = 3.0
    min_paraphrase = 4.0

    # read the dataset
    texts = []
    labels = []

    with open(sts_data, 'r', encoding='utf8') as dd:
        for line in dd:
            fields = line.strip().split("\t")
            labels.append(float(fields[4]))
            t1 = fields[5].lower()
            t2 = fields[6].lower()
            texts.append((t1,t2))

    labels = np.asarray(labels)

    # get an array of the rows where the labels are in the right interval
    # I like this numpy
    #pi_rows = np.where(np.logical_or(labels>=min_paraphrase, labels<=max_nonparaphrase))[0]
    # here's a loop if you don't like numpy
    pi_rows = [i for i,label in enumerate(labels) if label >=min_paraphrase or label<=max_nonparaphrase]

    pi_texts = [texts[i] for i in pi_rows]
    # 1221 for dev
    print(f"{len(pi_texts)} sentence pairs kept")

    # using indexing to get the right rows out of labels
    pi_y = labels[pi_rows]
    # convert to binary using threshold
    pi_y = pi_y > max_nonparaphrase

    num_nonparaphrase = (pi_y == False).sum()
    num_paraphrase = (pi_y == True).sum()
    # 957 for dev
    print(f"{num_nonparaphrase} non-paraphrase")
    # 264 for dev
    print(f"{num_paraphrase} paraphrase")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--sts_data", type=str, default="sts-dev.csv",
                        help="tab separated sts data in benchmark format")
    args = parser.parse_args()

    main(args.sts_data)
