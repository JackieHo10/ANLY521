Paraphrase Identification using string similarity
---------------------------------------------------

This project examines string similarity metrics for paraphrase identification.
It converts semantic textual similarity data to paraphrase identification data using threshholds.
Though semantics go beyond the surface representations seen in strings, some of these
metrics constitute a good benchmark system for detecting paraphrase.


Data is from the [STS benchmark](http://ixa2.si.ehu.es/stswiki/index.php/STSbenchmark).

Instructor repository at <https://github.com/emmerkhofer/paraphrase_logreg> . 

## Homework: pi_logreg.py

* Train a logistic regression for PI on the training data using string similarity metrics as features: 
["NIST", "BLEU", "Word Error Rate", "Longest common substring", "Levenshtein distance"]
* Use the logistic regression implementation in `sklearn`.
* Print your model accuracy on dev.
* Update the README.md with a description of your code and your accuracy on dev.
* **HINT:** You may copy any relevant code and README material from previous homework.
* Grading uses 
1) your pi_logreg.py code and 
2) your README.

This homework is submitted as a link to your Github repo on Canvas. You may submit the link early; 
we will grade the state of your repository at the deadline.



## lab.py

`lab.py` converts a STS dataset to PI and reports the number of remaining examples
and the distribution of paraphrase/nonparaphrase.

Example usage:

`python lab.py --sts_data stsbenchmark/sts-dev.csv`

## pi_logreg.py

TODO: Replace these instructions with a description of your code.
* Use `.md` filetype
* ~ 1 sentence about each of the metrics used.
* Describe what your script does.
* Include a usage example showing command line flags
* Describe your output.

## Results

TODO: paste your accuracy on dev here.

This system scores ______ . 
