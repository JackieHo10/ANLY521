# -*- coding: utf-8 -*-
#!/usr/bin/env python
"""
Created on Sun Feb 24 15:35:27 2019

@author: jacky
"""
'''
This is HW6 of ANLY521
references:
HW5 and in-class lab
'''

# import libraries
import argparse
import nltk
from nltk.metrics.distance import edit_distance
from nltk.translate.nist_score import sentence_nist
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import os
os.chdir(r'C:\Users\jacky\Desktop\paraphrase-logreg')
import warnings
warnings.filterwarnings("ignore")

# define a few help functions
def load_sts(sts_data):
    """Read a dataset from a file in STS benchmark format"""
    # read the dataset (from the lab)
    texts = []
    labels = []
    with open(sts_data, 'r', encoding='utf8') as dd:
        for line in dd:
            fields = line.strip().split("\t")
            labels.append(float(fields[4]))
            t1 = fields[5].lower()
            t2 = fields[6].lower()
            texts.append((t1,t2))
    labels = np.asarray(labels)
    return texts, labels

def sts_to_pi(texts, labels, min_paraphrase=4.0, max_nonparaphrase=3.0):
    """Convert a dataset from semantic textual similarity to paraphrase.
    Remove any examples that are > max_nonparaphrase and < min_paraphrase.
    labels must have shape [m,1] for sklearn models, where m is the number of examples"""
    # get an array of the rows where the labels are in the right interval
    pi_rows = [i for i,label in enumerate(labels) if label>=min_paraphrase or label<=max_nonparaphrase]
    pi_texts = [texts[i] for i in pi_rows]
    print(f"{len(pi_texts)} sentence pairs kept")
    # using indexing to get the right rows out of labels
    pi_y = labels[pi_rows]
    # convert to binary using threshold
    pi_y = pi_y > max_nonparaphrase
    num_nonparaphrase = (pi_y == False).sum()
    num_paraphrase = (pi_y == True).sum()
    print(f"{num_nonparaphrase} non-paraphrase")
    print(f"{num_paraphrase} paraphrase")    
    print(f"the shape of labels: {pi_y.shape}")
    return pi_texts, pi_y

def load_X(sent_pairs):
    """Create a matrix where every row is a pair of sentences and every column in a feature.
    Feature (column) order is not important to the algorithm."""
    features = ["NIST", "BLEU", "Word Error Rate", "Longest common substring", "Levenshtein distance"]
    # initialize a matrix with Pandas DataFrame
    df = pd.DataFrame(0, index=np.arange(len(sent_pairs)), columns=features)
    # import contents from HW5 to get features

    ## NIST ##
    nist_list = []
    length = len(sent_pairs)
    for d,pair_d in enumerate(sent_pairs[0:length]):
        t9, t10 = pair_d
        t5_toks = nltk.word_tokenize(t9)
        t6_toks = nltk.word_tokenize(t10)
        try:
            dist_nist_1 = sentence_nist([t5_toks, ], t6_toks)
            dist_nist_2 = sentence_nist([t6_toks, ], t5_toks)
            dist_nist = dist_nist_1 + dist_nist_2 # sentence order matters -> calculate both and sum them together
            nist_list.append(dist_nist)
        except ZeroDivisionError: # error handler to deal with ZeroDivisionError as described in the requirement
            nist_list.append(0)            
    
    ## BLEU ##    
    bleu_list = []
    length_1 = len(sent_pairs)
    for c,pair_c in enumerate(sent_pairs[0:length_1]):
        t7, t8 = pair_c
        t3_toks = nltk.word_tokenize(t7)
        t4_toks = nltk.word_tokenize(t8)
        dist_bleu_1 = nltk.translate.bleu_score.sentence_bleu([t3_toks, ], t4_toks)
        dist_bleu_2 = nltk.translate.bleu_score.sentence_bleu([t4_toks, ], t3_toks)
        dist_bleu = dist_bleu_1 + dist_bleu_2 # sentence order matters -> calculate both and sum them together
        bleu_list.append(dist_bleu)

    ## Word Error Rate ## 
    wer_list = []
    length_2 = len(sent_pairs)
    for b,pair_b in enumerate(sent_pairs[0:length_2]):
        t5, t6 = pair_b
        t1_toks = nltk.word_tokenize(t5) # tokenize first 
        t2_toks = nltk.word_tokenize(t6) 
        word_edit_dist = edit_distance(t1_toks, t2_toks)
        wer_score = (word_edit_dist/len(t1_toks)) + (word_edit_dist/len(t2_toks)) # sum them together
        dist_wer = wer_score   
        wer_list.append(dist_wer)

    ## Longest common substring ## 
    def LCS(X, Y, m, n):      
        LCSL = [[0 for k in range(n+1)] for l in range(m+1)]      
        result = 0   
        for i in range(m + 1): 
            for j in range(n + 1): 
                if (i == 0 or j == 0): 
                    LCSL[i][j] = 0
                elif (X[i-1] == Y[j-1]): 
                    LCSL[i][j] = LCSL[i-1][j-1] + 1
                    result = max(result, LCSL[i][j]) 
                else: 
                    LCSL[i][j] = 0
        return result 
    # get the length list
    lcs_list = []
    length_3 = len(sent_pairs)
    for a,pair_a in enumerate(sent_pairs[0:length_3]):
        t3, t4 = pair_a
        dist_lcs = LCS(t3, t4, len(t3), len(t4))
        lcs_list.append(dist_lcs)

    ## Levenshtein distance ##
    dis = []        
    length_4 = len(sent_pairs)
    for i,pair in enumerate(sent_pairs[0:length_4]):
        t1, t2 = pair
        # calculate the edit distance
        dist = edit_distance(t1, t2)
        dis.append(dist)
            
    return df, nist_list, bleu_list, wer_list, lcs_list, dis

# main function below
def main(sts_train_file, sts_dev_file):
    """Fits a logistic regression for paraphrase identification, using string similarity metrics as features.
    Prints accuracy on held-out data. Data is formatted as in the STS benchmark"""
    
    min_paraphrase = 4.0
    max_nonparaphrase = 3.0    
    
    # loading train
    train_texts_sts, train_y_sts = load_sts(sts_train_file)
    train_texts, train_y = sts_to_pi(train_texts_sts, train_y_sts,
      min_paraphrase=min_paraphrase, max_nonparaphrase=max_nonparaphrase)
    
    # loading dev
    dev_texts_sts, dev_y_sts = load_sts(sts_dev_file)
    dev_texts, dev_y = sts_to_pi(dev_texts_sts, dev_y_sts,
      min_paraphrase=min_paraphrase, max_nonparaphrase=max_nonparaphrase)
    
    print(f"Found {len(train_texts)} training pairs")
    print(f"Found {len(dev_texts)} dev pairs")
    
    # fit a logistic regression on the data
    print("Fitting and evaluating model")
    
    # train a multinomial logistic regression
    mynp = np.array([load_X(train_texts)[1],load_X(train_texts)[2],load_X(train_texts)[3],
                     load_X(train_texts)[4],load_X(train_texts)[5]])
    mynp = mynp.transpose()
    print(mynp)
    print(mynp.shape)
    
    logisticRegr = LogisticRegression()
    logisticRegr.fit(mynp, train_y)
    
    mynp_1 = np.array([load_X(dev_texts)[1],load_X(dev_texts)[2],load_X(dev_texts)[3],
                     load_X(dev_texts)[4],load_X(dev_texts)[5]])
    mynp_1 = mynp_1.transpose()
    print(mynp_1)
    print(mynp_1.shape)
    
    predictions = logisticRegr.predict(mynp_1)
    print(predictions)
    print(len(predictions))
    
    # get accuracy of model
    predictions = np.array(predictions).reshape(-1, 1)
    dev_y = np.array(dev_y).reshape(-1, 1)       
    print(predictions.shape)
    print(predictions)
    print(dev_y.shape)
    print(dev_y)
    
    acc_score = accuracy_score(dev_y, predictions)
    print(f"the model accuracy score: {acc_score:.3f}")
       
    
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--sts_dev_file", type=str, default="sts-dev.csv",
                        help="dev file")
    parser.add_argument("--sts_train_file", type=str, default="sts-train.csv",
                        help="train file")
    args = parser.parse_args()
    main(args.sts_train_file, args.sts_dev_file)








