# -*- coding: utf-8 -*-
"""
Created on Mon Feb 11 14:39:52 2019

@author: jacky
"""
'''
This is HW4 for ANLY521
'''
# import libraries
import tmdbsimple as tmdb
import re
import time
import argparse
import collections
from urllib.request import HTTPError
import os
os.chdir(r'C:\Users\jacky\Desktop\homework')

def main(api_key, output_file):
    """Use tmdbsimple to create a dataset with the reviews from exactly 100 movies.
    Each line of the tsv contains <movie_id>\t<author_id>\t<review_string> .
    tsvchecker.py confirms that your file is readable and contains data for exactly 100 movies. """
    tmdb.API_KEY = api_key    
    # get 100+ movie ids
    discover = tmdb.Discover() # the limit of one call is 20
    movie_list = discover.movie(year=2018)
    movie_list_1 = discover.movie(year=2010)
    movie_list_2 = discover.movie(year=1930)
    movie_list_3 = discover.movie(year=1970)
    movie_list_4 = discover.movie(year=1960)    
    movie_list_5 = discover.movie(year=2007)
    movie_list_6 = discover.movie(year=2006)
    movie_list_7 = discover.movie(year=2005)
    movie_list_8 = discover.movie(year=2000)
    movie_list_9 = discover.movie(year=1995)
    movie_list_10 = discover.movie(year=1993)
    movie_list_11 = discover.movie(year=1991)
    movie_list_12 = discover.movie(year=2013)

    id_list = movie_list['results']
    id_list_1 = movie_list_1['results']
    id_list_2 = movie_list_2['results']
    id_list_3 = movie_list_3['results']
    id_list_4 = movie_list_4['results']
    id_list_5 = movie_list_5['results']
    id_list_6 = movie_list_6['results']
    id_list_7 = movie_list_7['results']
    id_list_8 = movie_list_8['results']
    id_list_9 = movie_list_9['results']
    id_list_10 = movie_list_10['results']
    id_list_11 = movie_list_11['results']
    id_list_12 = movie_list_12['results']
    
    id_values_list = [d['id'] for d in id_list]
    id_values_list_1 = [d['id'] for d in id_list_1]
    id_values_list_2 = [d['id'] for d in id_list_2]
    id_values_list_3 = [d['id'] for d in id_list_3]
    id_values_list_4 = [d['id'] for d in id_list_4]
    id_values_list_5 = [d['id'] for d in id_list_5]
    id_values_list_6 = [d['id'] for d in id_list_6]
    id_values_list_7 = [d['id'] for d in id_list_7]
    id_values_list_8 = [d['id'] for d in id_list_8]
    id_values_list_9 = [d['id'] for d in id_list_9]
    id_values_list_10 = [d['id'] for d in id_list_10]
    id_values_list_11 = [d['id'] for d in id_list_11]
    id_values_list_12 = [d['id'] for d in id_list_12]
    
    # combine all id lists and remove duplicates
    movie_ids = id_values_list + id_values_list_1 + id_values_list_2 + id_values_list_3 + id_values_list_4 + id_values_list_5 + id_values_list_6 + id_values_list_7 + id_values_list_8 + id_values_list_9 + id_values_list_10 + id_values_list_11 + id_values_list_12 
    movie_ids = list(set(movie_ids))
    print(movie_ids)
    print(len(movie_ids))    
    # double check whether or not there still exist duplicates
    print([item for item, count in collections.Counter(movie_ids).items() if count>1])
    
    # request review data from the api (exact 100 movies)
    final_review_list = [] # initialize
    for index in range(0, 20):
        while True:                
            try:             
                movie = tmdb.Movies(movie_ids[index]) # this is one request
                reviews = movie.reviews() # one request
                dict_you_want = { your_key: reviews[your_key] for your_key in ['id', 'results'] } # create a new dictionary with only 'id' and 'results'
                if len(dict_you_want['results']) != 0:
                    final_review_list.append(dict_you_want)
                break
            except HTTPError:
                print("HTTPError!!") # react to HTTPError
                
    print("Wait for 20 seconds!")
    time.sleep(20) # sleep for 20 seconds to avoid api rate limit
    
    for index in range(20, 40):
        while True:                
            try:             
                movie_1 = tmdb.Movies(movie_ids[index]) # this is one request
                reviews_1 = movie_1.reviews() # one request
                dict_you_want_1 = { your_key: reviews_1[your_key] for your_key in ['id', 'results'] }
                if len(dict_you_want_1['results']) != 0:
                    final_review_list.append(dict_you_want_1)
                break
            except HTTPError:
                print("HTTPError!!")

    print("Wait for 20 seconds!")
    time.sleep(20)
    
    for index in range(40, 60):
        while True:                
            try:             
                movie_2 = tmdb.Movies(movie_ids[index]) # this is one request
                reviews_2 = movie_2.reviews() # one request
                dict_you_want_2 = { your_key: reviews_2[your_key] for your_key in ['id', 'results'] }
                if len(dict_you_want_2['results']) != 0:
                    final_review_list.append(dict_you_want_2)
                break
            except HTTPError:
                print("HTTPError!!")
    
    print("Wait for 20 seconds!")
    time.sleep(20)
    
    for index in range(60, 80):
        while True:                
            try:             
                movie_3 = tmdb.Movies(movie_ids[index]) # this is one request
                reviews_3 = movie_3.reviews() # one request
                dict_you_want_3 = { your_key: reviews_3[your_key] for your_key in ['id', 'results'] }
                if len(dict_you_want_3['results']) != 0:
                    final_review_list.append(dict_you_want_3)
                break
            except HTTPError:
                print("HTTPError!!")
        
    print("Wait for 20 seconds!")
    time.sleep(20)
    
    for index in range(80, 100):
        while True:                
            try:             
                movie_4 = tmdb.Movies(movie_ids[index]) # this is one request
                reviews_4 = movie_4.reviews() # one request
                dict_you_want_4 = { your_key: reviews_4[your_key] for your_key in ['id', 'results'] }
                if len(dict_you_want_4['results']) != 0:
                    final_review_list.append(dict_you_want_4)
                break
            except HTTPError:
                print("HTTPError!!")
            
    print("Wait for 20 seconds!")
    time.sleep(20)
    
    for index in range(100, 120):
        while True:                
            try:             
                movie_5 = tmdb.Movies(movie_ids[index]) # this is one request
                reviews_5 = movie_5.reviews() # one request
                dict_you_want_5 = { your_key: reviews_5[your_key] for your_key in ['id', 'results'] }
                if len(dict_you_want_5['results']) != 0:
                    final_review_list.append(dict_you_want_5)
                break
            except HTTPError:
                print("HTTPError!!")
                
    print("Wait for 20 seconds!")
    time.sleep(20)
    
    for index in range(120, 140):
        while True:                
            try:             
                movie_6 = tmdb.Movies(movie_ids[index]) # this is one request
                reviews_6 = movie_6.reviews() # one request
                dict_you_want_6 = { your_key: reviews_6[your_key] for your_key in ['id', 'results'] }
                if len(dict_you_want_6['results']) != 0:
                    final_review_list.append(dict_you_want_6)
                break
            except HTTPError:
                print("HTTPError!!")
                
    print("Wait for 20 seconds!")
    time.sleep(20)
    
    for index in range(140, 160):
        while True:                
            try:             
                movie_7 = tmdb.Movies(movie_ids[index]) # this is one request
                reviews_7 = movie_7.reviews() # one request
                dict_you_want_7 = { your_key: reviews_7[your_key] for your_key in ['id', 'results'] }
                if len(dict_you_want_7['results']) != 0:
                    final_review_list.append(dict_you_want_7)
                break
            except HTTPError:
                print("HTTPError!!")
    
    print("Wait for 20 seconds!")
    time.sleep(20)
    
    for index in range(160, 180):
        while True:                
            try:             
                movie_8 = tmdb.Movies(movie_ids[index]) # this is one request
                reviews_8 = movie_8.reviews() # one request
                dict_you_want_8 = { your_key: reviews_8[your_key] for your_key in ['id', 'results'] }
                if len(dict_you_want_8['results']) != 0:
                    final_review_list.append(dict_you_want_8)
                break
            except HTTPError:
                print("HTTPError!!")
    
    print("Wait for 20 seconds!")
    time.sleep(20)
    
    for index in range(180, 200):
        while True:                
            try:             
                movie_9 = tmdb.Movies(movie_ids[index]) # this is one request
                reviews_9 = movie_9.reviews() # one request
                dict_you_want_9 = { your_key: reviews_9[your_key] for your_key in ['id', 'results'] }
                if len(final_review_list) < 100:
                    if len(dict_you_want_9['results']) != 0:
                        final_review_list.append(dict_you_want_9)
                break
            except HTTPError:
                print("HTTPError!!")
    
    print(len(final_review_list))
    print("Wait for 20 seconds!")
    time.sleep(20)    
        
    for index in range(200, len(movie_ids)):
        while True:                
            try:             
                movie_10 = tmdb.Movies(movie_ids[index]) # this is one request
                reviews_10 = movie_10.reviews() # one request
                dict_you_want_10 = { your_key: reviews_10[your_key] for your_key in ['id', 'results'] }
                if len(final_review_list) < 100:
                    if len(dict_you_want_10['results']) != 0:
                        final_review_list.append(dict_you_want_10)
                break
            except HTTPError:
                print("HTTPError!!")
    
    # check the final results
    print(final_review_list)
    print(len(final_review_list))    
    
    # create the desired dataset and save the output to a .tsv file
    with open("tmdb_dataset.tsv", "w+", encoding="utf-8") as record_file:
        for review_dict in final_review_list:
            mov_id = review_dict['id']
            auth = review_dict['results'][0]['author']
            text = review_dict['results'][0]['content']
            # use regex to remove '\n', '\r', and '\t' for formatting requirement
            text_1 = re.sub('\n', ' ', text)
            text_2 = re.sub('\t', ' ', text_1)
            text_3 = re.sub('\r', ' ', text_2)        
            #print(f"{mov_id}\t{auth}\t{text_3}")
            record_file.write(f"{mov_id}\t{auth}\t{text_3}\n")
    
    
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--key_file", type=str, default="api_key.txt",
                        help="text file containing API key")
    parser.add_argument("--output_file", type=str, default="tmdb_dataset.tsv",
                        help="tsv: movie, author, review")
    args = parser.parse_args()

    with open(args.key_file, 'r') as key_path:
        key = key_path.read().strip()
    main(key, args.output_file)
    
    


    