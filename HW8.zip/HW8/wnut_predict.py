# -*- coding: utf-8 -*-
#!/usr/bin/env python
"""
Created on Mon Apr  1 13:24:03 2019

@author: jacky
"""
'''
This is HW8 of ANLY521
'''

# https://cs.nyu.edu/grishman/jet/guide/PennPOS.html
# import libraries
import re
import csv
from nltk import pos_tag, ne_chunk
from nltk import tree2conlltags
import argparse
import os
os.chdir(r'C:\Users\jacky\Desktop\ner-eval')
import warnings
warnings.filterwarnings("ignore")

# borrowed from wnuteval.py
# splits data that is separated with an extra newline
def get_sents(lines):
    """
    Args:
        lines (Iterable[str]): the lines

    Yields:
        List[str]: sentences as list
    """
    sents = []
    sent = []
    stripped_lines = (line.strip() for line in lines)
    for line in stripped_lines:
        if line == '':
            sents.append(sent)
            sent = []
        else:
            sent.append(line)
    sents.append(sent)
    return sents

    
def main(wnut_data, output_file):
    # open data and read sentences out
    with open(wnut_data, 'r', encoding='utf8') as od:
        orig_lines = od.readlines()
    
    all_sents = get_sents(orig_lines) # BIO tagging
    
    nes_list = []
    for index in range(0, len(all_sents)):
        sent = all_sents[index]
        sent_words = [line.split('\t')[0] for line in sent]
        # input is just a list of tokens, not further preprocessed
        # named entity chunking happens off POS tags
        sent_with_pos = pos_tag(sent_words)
        # run the default named entity recognizer
        nes = ne_chunk(sent_with_pos) # returns nltk.tree.Tree objects
        nes_list.append(nes)
        iob_tags = tree2conlltags(nes)
        #print(iob_tags)
        
        sent_gold = [line.split('\t')[1] for line in sent]                            
        iob_wnut = []        
        for i, chunk in enumerate(iob_tags):                        
            chunk_list = list(chunk)
            chunk_list[2] = re.sub(r'ORGANIZATION', 'corporation', chunk_list[2])
            chunk_list[2] = re.sub(r'PERSON', 'person', chunk_list[2])        
            chunk_list[2] = re.sub(r'LOCATION', 'location', chunk_list[2])
            chunk_list[2] = re.sub(r'DATE', 'None', chunk_list[2])
            chunk_list[2] = re.sub(r'TIME', 'None', chunk_list[2])
            chunk_list[2] = re.sub(r'MONEY', 'None', chunk_list[2])
            chunk_list[2] = re.sub(r'PERCENT', 'None', chunk_list[2])
            chunk_list[2] = re.sub(r'FACILITY', 'location', chunk_list[2])
            chunk_list[2] = re.sub(r'GPE', 'location', chunk_list[2])
            chunk_list[2] = re.sub(r'B-GSP', 'O', chunk_list[2])            
            new_chunk = [chunk_list[0], sent_gold[i], chunk_list[2]]
            iob_wnut.append(new_chunk)

            # produce the output
            with open(output_file, 'a', encoding='utf8', newline='') as ner_file:
                tsv_output = csv.writer(ner_file, delimiter='\t')
                tsv_output.writerow(new_chunk)
        with open(output_file, 'a', encoding='utf8', newline='') as ner_file_1:
                tsv_output_1 = csv.writer(ner_file_1)
                tsv_output_1.writerow('')
        
        
if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--wnut_file", type=str,
                        default="emerging_entities_17/emerging.dev.conll",
                        help="wnut tsv file including annotations")
    parser.add_argument("--output_file", type=str, default="predictions.tsv",
                        help="file to write results")

    args = parser.parse_args()

    main(args.wnut_file, args.output_file)











