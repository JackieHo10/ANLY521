# ANLY 521 HW2
In this assignment, the goal is to practice creating feature vectors from text. We use IMDB reviews data file. It 
helps us get familiar with numpy arrays, operations on arrays, slicing arrays, counting vectors as features, 
binary vectors, normalized count vectors, loading labels, and splitting off a percent of random held-out data. 
