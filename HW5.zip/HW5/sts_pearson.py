# -*- coding: utf-8 -*-
#!/usr/bin/env python
"""
Created on Mon Feb 18 21:28:18 2019

@author: jacky
"""
'''
This is ANLY521 HW5
references: 
lab_liz.py
https://www.geeksforgeeks.org/longest-common-substring-dp-29/
'''

# import libraries
import argparse
import nltk
from scipy.stats.stats import pearsonr
from nltk.metrics.distance import edit_distance
from nltk.translate.nist_score import sentence_nist
import os
os.chdir(r'C:\Users\jacky\Desktop\stsbenchmark')
import warnings
warnings.filterwarnings("ignore")

def main(sts_data, output_file):
    """Calculate pearson correlation between semantic similarity scores and string similarity metrics.
    Data is formatted as in the STS benchmark"""
    with open(output_file, 'w', encoding='utf8') as out:
        out.write(f"Semantic textual similarity for stsbenchmark/{sts_data}\n")
    # load dataset
    texts = []
    labels = []
    with open(sts_data, 'r', encoding='utf8') as dd:
        for line in dd:
            fields = line.strip().split("\t")
            labels.append(float(fields[4]))
            t1 = fields[5].lower()
            t2 = fields[6].lower()
            texts.append((t1, t2))
    print(f"Found {len(texts)} STS pairs")
    
    ## NIST ##
    # get NIST score by using nltk package
    nist_list = []
    length = len(texts)
    for d,pair_d in enumerate(texts[0:length]):
        t9, t10 = pair_d
        t5_toks = nltk.word_tokenize(t9)
        t6_toks = nltk.word_tokenize(t10)
        try:
            dist_nist_1 = sentence_nist([t5_toks, ], t6_toks)
            dist_nist_2 = sentence_nist([t6_toks, ], t5_toks)
            dist_nist = dist_nist_1 + dist_nist_2 # sentence order matters -> calculate both and sum them together
            nist_list.append(dist_nist)
        except ZeroDivisionError: # error handler to deal with ZeroDivisionError as described in the requirement
            nist_list.append(0)            
    # calculate pearson correlation
    pearson_NIST = pearsonr(labels, nist_list)
    print(pearson_NIST)    
    with open(output_file, 'a', encoding='utf8') as out:
        out.write(f"NIST correlation: {pearson_NIST[0]:.3f}\n")
    
    ## BLEU ##
    # get BLEU score by using nltk package    
    bleu_list = []
    length = len(texts)
    for c,pair_c in enumerate(texts[0:length]):
        t7, t8 = pair_c
        t3_toks = nltk.word_tokenize(t7)
        t4_toks = nltk.word_tokenize(t8)
        dist_bleu_1 = nltk.translate.bleu_score.sentence_bleu([t3_toks, ], t4_toks)
        dist_bleu_2 = nltk.translate.bleu_score.sentence_bleu([t4_toks, ], t3_toks)
        dist_bleu = dist_bleu_1 + dist_bleu_2 # sentence order matters -> calculate both and sum them together
        bleu_list.append(dist_bleu)
    # calculate pearson correlation
    pearson_BLEU = pearsonr(labels, bleu_list)
    print(pearson_BLEU)    
    with open(output_file, 'a', encoding='utf8') as out:
        out.write(f"BLEU correlation: {pearson_BLEU[0]:.3f}\n")
    
    ## Word Error Rate ##
    # get WER based on Liz's definition 
    wer_list = []
    length = len(texts)
    for b,pair_b in enumerate(texts[0:length]):
        t5, t6 = pair_b
        t1_toks = nltk.word_tokenize(t5) # tokenize first 
        t2_toks = nltk.word_tokenize(t6) 
        word_edit_dist = edit_distance(t1_toks, t2_toks)
        wer_score = (word_edit_dist/len(t1_toks)) + (word_edit_dist/len(t2_toks)) # sum them together
        dist_wer = wer_score   
        wer_list.append(dist_wer)
    # calculate pearson correlation
    pearson_WER = pearsonr(labels, wer_list)
    print(pearson_WER)    
    with open(output_file, 'a', encoding='utf8') as out:
        out.write(f"Word Error Rate correlation: {pearson_WER[0]:.3f}\n")
            
    ## Longest common substring ## 
    # define a function to get the length of LCS of two strings
    def LCS(X, Y, m, n):      
        LCSL = [[0 for k in range(n+1)] for l in range(m+1)]      
        result = 0   
        for i in range(m + 1): 
            for j in range(n + 1): 
                if (i == 0 or j == 0): 
                    LCSL[i][j] = 0
                elif (X[i-1] == Y[j-1]): 
                    LCSL[i][j] = LCSL[i-1][j-1] + 1
                    result = max(result, LCSL[i][j]) 
                else: 
                    LCSL[i][j] = 0
        return result 
    # get the length list
    lcs_list = []
    length = len(texts)
    for a,pair_a in enumerate(texts[0:length]):
        t3, t4 = pair_a
        dist_lcs = LCS(t3, t4, len(t3), len(t4))
        lcs_list.append(dist_lcs)
    # calculate pearson correlation
    pearson_LCS = pearsonr(labels, lcs_list)
    print(pearson_LCS)    
    with open(output_file, 'a', encoding='utf8') as out:
        out.write(f"Longest common substring correlation: {pearson_LCS[0]:.3f}\n")
    
    ## Levenshtein distance ##
    dis = []        
    length = len(texts)
    for i,pair in enumerate(texts[0:length]):
        t1, t2 = pair
        #print(f"Sentences: {t1}\t{t2}")
        # calculate the edit distance
        dist = edit_distance(t1, t2)
        dis.append(dist)
        #print(f"Label: {labels[i]}, edit distance: {dist}")
    # calculate pearson correlation
    pearson_Levenshtein = pearsonr(labels, dis)
    print(pearson_Levenshtein)    
    with open(output_file, 'a', encoding='utf8') as out:
        out.write(f"Levenshtein distance correlation: {pearson_Levenshtein[0]:.3f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--sts_data", type=str, default="sts-test.csv",
                        help="tab separated sts data in benchmark format")# make a small change here for default 
    parser.add_argument("--output_file", type=str, default="test_output.txt",
                        help="report on string similarity ")
    args = parser.parse_args()

    main(args.sts_data, args.output_file)







