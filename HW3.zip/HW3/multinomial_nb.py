#!/usr/bin/env python
"""
This is HW3 for ANLY521
reference: 
solution code for HW2
https://machinelearningmastery.com/implement-baseline-machine-learning-algorithms-scratch-python/
"""
#import libraries
from sklearn.naive_bayes import MultinomialNB
from collections import Counter
from sklearn import metrics
import numpy as np
import argparse
import os
os.chdir(r'C:\Users\jacky\Desktop\nb_assignment')

#define a help function to load function words
def load_function_words(resource_path):
    """load a newline separated text file of function words.
    Return a list"""
    f_words = []
    with open(resource_path, 'r') as f:
        for line in f:
            if line.strip():
                f_words.append(line.lower().strip())
    return f_words

#a help function to conduct train/test split
def split_dataset(X, y, hold_out_percent):
    """shuffle and split the dataset. Returns two tuples:
    (X_train, y_train, train_indices): train inputs
    (X_val, y_val, val_indices): validation inputs"""
    m = X.shape[0]
    #number of elements in train
    split_at = int(m * hold_out_percent)
    array_shuff = np.random.permutation(np.arange(m))
    #shuffle is in place
    np.random.shuffle(array_shuff)
    train_inds = array_shuff[:split_at]
    val_inds = array_shuff[split_at:]
    return ((X[train_inds],y[train_inds],train_inds), (X[val_inds],y[val_inds],val_inds))

#use zero rule algorithm for classification
def zero_rule_algorithm_classification(training, test):
	output_values = [row for row in training]
	prediction = max(set(output_values), key=output_values.count)
	predicted = [prediction for i in range(len(test))]
	return predicted

def main(data_file, vocab_path):
    """Build an authorship attribution classifier using MultinomialNaiveBayes for two authors"""
    #load in function words, reviews, and authors
    function_words = load_function_words(vocab_path) 
    reviews = []
    authors = []
    with open(data_file, 'r') as data_file:
        for line in data_file:
            fields = line.strip().split("\t")
            reviews.append(fields[-1])
            authors.append(fields[0])
    
    #create feature vectors (raw and binary)
    num_reviews = len(reviews)
    review_features = np.zeros((num_reviews, len(function_words)), dtype=np.int64)
    #row is which review
    for i,review in enumerate(reviews):
        review_word_counts = Counter(review.lower().split())
        #column is which word
        for j,f_word in enumerate(function_words):
            if f_word in review_word_counts:
                review_features[i,j] = review_word_counts[f_word]
    print(f"The raw count matrix is: {review_features}")
    #change features from count to binary (word occurs or does not)
    word_binary = (review_features>0)
    print(f"The binary matrix is: {word_binary}")

    #load author data into a label array, assigning a class index per unique author
    author_set = sorted(set(authors))
    label_list = [author_set.index(auth) for auth in authors]
    labels = np.asarray(label_list) #two classes: 0 and 1
    
    #split data
    train, val = split_dataset(review_features, labels, 0.9) #90% train; 10% validation
    train_1, val_1 = split_dataset(word_binary, labels, 0.9) #90% train; 10% validation
    
    #run the most common class baseline model: the Zero Rule Algorithm 
    #1
    train_zero = list(train[1])
    test_zero = val[0]
    predictions_zero = zero_rule_algorithm_classification(train_zero, test_zero)
    print(predictions_zero)
    print(len(train[1]))
    print(len(val[0]))
    print(len(predictions_zero))
    counter_0 = 0
    counter_1 = 0
    for i in range(0, len(train_zero)):
        if train_zero[i] == 0:
            counter_0 += 1
        else:
            counter_1 += 1    
    print(counter_0)
    print(counter_1)        
    if counter_0 >= counter_1:
        accuracy_zero = int(counter_0) / (int(counter_0) + int(counter_1))
    else:
        accuracy_zero = int(counter_1) / (int(counter_0) + int(counter_1))
    print("the baseline accuracy on raw count features is: ")
    print(accuracy_zero)
    #2
    #train_zero_1 = list(train_1[1])
    #test_zero_1 = val_1[0]
    #predictions_zero_1 = zero_rule_algorithm_classification(train_zero_1, test_zero_1)
    #print(predictions_zero_1)    
    #print(len(train_1[1]))
    #print(len(val_1[0]))
    #print(len(predictions_zero_1))    
    #counter_0_a = 0
    #counter_1_a = 0
    #for i in range(0, len(train_zero_1)):
    #    if train_zero_1[i] == 0:
    #        counter_0_a += 1
    #    else:
    #        counter_1_a += 1    
    #print(counter_0_a)
    #print(counter_1_a)        
    #if counter_0_a >= counter_1_a:
    #    accuracy_zero_1 = int(counter_0_a) / (int(counter_0_a) + int(counter_1_a))
    #else:
    #    accuracy_zero_1 = int(counter_1_a) / (int(counter_0_a) + int(counter_1_a))
    #print("the baseline accuracy on binary features is: ")
    #print(accuracy_zero_1)
    
    #apply sklearn.naive_bayes.MultinomialNB
    #1
    clf = MultinomialNB()
    clf.fit(train[0], train[1])
    MultinomialNB(alpha=1.0, class_prior=None, fit_prior=True) #use default values for all 3 parameters
    print("the mean accuracy for MultinomialNB on raw count features: ")
    print(clf.score(val[0], val[1], sample_weight=None))
    #double check the accuracy
    y_pred_class = clf.predict(val[0])
    print(metrics.accuracy_score(val[1], y_pred_class))
    #2
    clf_1 = MultinomialNB()
    clf_1.fit(train_1[0], train_1[1])
    MultinomialNB(alpha=1.0, class_prior=None, fit_prior=True) #use default values for all 3 parameters
    print("the mean accuracy for MultinomialNB on binary features: ")
    print(clf_1.score(val_1[0], val_1[1], sample_weight=None))
    #double check the accuracy
    y_pred_class_1 = clf_1.predict(val_1[0])
    print(metrics.accuracy_score(val_1[1], y_pred_class_1))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='feature vector homework')
    parser.add_argument('--path', type=str, default="imdb_twoauthor.tsv",
                        help='path to author dataset')
    parser.add_argument('--function_words_path', type=str, default="ewl_function_words.txt",
                        help='path to the list of words to use as features')
    args = parser.parse_args()

    main(args.path, args.function_words_path)







