# ANLY 521 HW1
In this assignment, the goal is to update the price of product by multiplying the original price by a multiplier. 
We have keys provided by the instructor which associate products with their categories and categories with their multipliers. 
For instance, "beef $5.99" is in category "meat" and "meat" has a multiplier 1.2. It means the new price should be 7.188.
Substitute by using "beef $7.19". 
By the way, the code uses the command line arguments for easy access. 