#!/usr/bin/env python
"""
This is the Assignment #1 for ANLY521
"""
# import libraries
import argparse
import re
import os
os.chdir(r'C:\Users\jacky\Desktop\pycomplx_1')

def main(old_menu, new_menu, category_key, update_key):
    """describe your function here"""
    old_menu_lines = []
    category_key_lines = []
    update_key_lines = []
    # add code to read the old menu and look for items with price updates
    with open(old_menu, 'r') as orig_menu:
        for line in orig_menu:
            old_menu_lines.append(line)
    with open(category_key, 'r') as cat_key:
        for line in cat_key:
            category_key_lines.append(line.rstrip('\n'))
    with open(update_key, 'r') as upt_key:
        for line in upt_key:
            update_key_lines.append(line.rstrip('\n'))
    # combine keys by regex
    combine_key = []
    for i in range(0, len(category_key_lines)):
        for j in range(0, len(update_key_lines)):
            if category_key_lines[i].split('\t')[1] == update_key_lines[j].split('\t')[0]:
                replaced = re.sub(category_key_lines[i].split('\t')[1], update_key_lines[j].split('\t')[1], category_key_lines[i])
                combine_key.append(replaced)
    # update the prices by regex
    new_menu_lines = []
    for k in range(0, len(old_menu_lines)):
        # ignore lines without '$' sign
        if len(re.findall(r'\$', old_menu_lines[k])) == 0:
            new_menu_lines.append(old_menu_lines[k])
        else:    
            a = len(new_menu_lines)
            for l in range(0, len(combine_key)):
                if combine_key[l].split('\t')[0] in old_menu_lines[k].split('\n')[0] and any(s in old_menu_lines[k].split('\n')[0].replace(',', '').replace('\t', ' ').split(' ') for s in combine_key[l].replace('\t', ' ').split(' ')):
                    m = re.search(r'\$[0-9]{1,3}([.][0-9]{1,2})?', old_menu_lines[k].split('\n')[0])
                    n = re.search(r'[0-9]{1,3}([.][0-9]{1,2})?', str(m.group(0)))
                    new_price = float(combine_key[l].split('\t')[1]) * float(n.group(0))
                    # use stupid f-string
                    money = '$'
                    price_temp = "%0.2f" % new_price # string formatting operation to keep two decimal places
                    new_price_update = f'{money}{price_temp}'        
                    #print(new_price_update) 
                    new_menu_lines_element = re.sub(r'\$[0-9]{1,3}([.][0-9]{1,2})?', new_price_update, old_menu_lines[k])
                    new_menu_lines.append(new_menu_lines_element)
                else:
                    pass
            b = len(new_menu_lines)
            # check the length of the list to see whether or not a new string has been added
            if b > a:
                pass
            else:
                new_menu_lines.append(old_menu_lines[k])
            
    print(old_menu_lines)            
    print(new_menu_lines)     
    
    #string = old_menu_lines[2].split('\n')[0]
    #print(string.find(combine_key[3].split('\t')[0]))
    #print(old_menu_lines[3].split('\n')[0].replace(',', '').split(' '))
    #print(combine_key[1].split('\t'))
    #print(combine_key)
    #if any(s in old_menu_lines[3].split('\n')[0].replace(',', '').split(' ') for s in combine_key[1].replace('\t', ' ').split(' ')):
    #    print(True)
    #else:
    #    print(False)
        
    # write a new file with your updates
    with open(new_menu, 'w') as new_menu_out:
        for item in new_menu_lines:
            new_menu_out.write(item)

if __name__ == '__main__':
    # command-line options
    parser = argparse.ArgumentParser(description='Update a menu')
    parser.add_argument('--path', type=str, default="practice_menu.txt",
                        help='path to the menu to update')
    parser.add_argument('--output_path', type=str, default="practice_menu_new.txt",
                        help='path to write the updated menu')
    parser.add_argument('--category_key', type=str, default="item_categories.txt",
                        help='path to the key to item categories')
    parser.add_argument('--update_key', type=str, default="category_update.txt",
                        help='path to the key to item categories')

    args = parser.parse_args()
    old_menu = args.path
    new_menu = args.output_path
    category_key = args.category_key
    update_key = args.update_key

    main(old_menu, new_menu, category_key, update_key)

